Extending via CFFI
------------------

.. literalinclude:: ../../../../../numpy/random/_examples/cffi/extending.py
    :language: python
