---
name: a) Bug fix
about: Select this if you're fixing a bug in Keras.
labels: bugfix
---

<!--
Please make sure you've read and understood our contributing guidelines;
https://github.com/keras-team/keras/blob/master/CONTRIBUTING.md
-->

**- What bug I fixed**

This pull request fixes #issue_number_here .

**- How I fixed it**

**- How you can verify it**
<!-- You need a good justification for not including tests for the bug you fixed. -->
