---
name: e) `keras.applications` users
about: Select this if your issue is related to the `keras.applications` module.

---


The [keras.applications](https://github.com/keras-team/keras-applications) module has been splitted from the main Keras repository.

Please submit your issue using this [link](https://github.com/keras-team/keras-applications/issues/new).

Thank you!
