
:mod:`matplotlib.backends.backend_mixed`
========================================

.. automodule:: matplotlib.backends.backend_mixed
   :members:
   :show-inheritance:
