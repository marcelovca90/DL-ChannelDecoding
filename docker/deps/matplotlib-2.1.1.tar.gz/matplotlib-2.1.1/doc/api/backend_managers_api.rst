
:mod:`matplotlib.backend_managers`
===================================

.. automodule:: matplotlib.backend_managers
   :members:
   :undoc-members:
   :show-inheritance:
