****
path
****


:mod:`matplotlib.path`
=======================

.. automodule:: matplotlib.path
   :members:
   :undoc-members:
   :show-inheritance:
