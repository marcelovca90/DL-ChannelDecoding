****************
dviread
****************

:mod:`matplotlib.dviread`
=========================

.. automodule:: matplotlib.dviread
   :members:
   :undoc-members:
   :exclude-members: Dvi
   :show-inheritance:

.. autoclass:: matplotlib.dviread.Dvi
   :members: __iter__,close
   :show-inheritance:
